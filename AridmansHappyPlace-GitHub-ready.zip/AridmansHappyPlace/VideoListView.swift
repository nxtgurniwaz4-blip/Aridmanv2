import SwiftUI

struct VideoListView: View {
    @EnvironmentObject private var catalog: VideoCatalog
    let category: VideoCategory

    private let columns = [
        GridItem(.adaptive(minimum: 260), spacing: 18)
    ]

    private var videos: [VideoItem] {
        catalog.videos(for: category)
    }

    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 20) {
                if videos.isEmpty {
                    emptyState
                } else {
                    ForEach(videos) { video in
                        VideoCard(video: video)
                    }
                }
            }
            .padding(18)
        }
        .background(
            LinearGradient(
                colors: [Color.cyan.opacity(0.10), Color.white],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
        )
        .navigationTitle("\(category.emoji) \(category.rawValue)")
        .navigationBarTitleDisplayMode(.large)
    }

    private var emptyState: some View {
        VStack(spacing: 12) {
            Text("😊")
                .font(.system(size: 60))
            Text("No videos in this category yet")
                .font(.system(size: 22, weight: .heavy, design: .rounded))
                .multilineTextAlignment(.center)
            Text("The catalog can be updated later without changing the app layout.")
                .font(.body)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(50)
    }
}

private struct VideoCard: View {
    let video: VideoItem

    var body: some View {
        Group {
            if let url = video.youtubeURL {
                Link(destination: url) {
                    cardContent
                }
            } else {
                cardContent
            }
        }
        .buttonStyle(.plain)
    }

    private var cardContent: some View {
        VStack(alignment: .leading, spacing: 10) {
            ThumbnailView(url: video.thumbnailURL)
                .frame(maxWidth: .infinity)
                .aspectRatio(16 / 9, contentMode: .fit)
                .clipShape(RoundedRectangle(cornerRadius: 22, style: .continuous))

            Text(video.title)
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(.primary)
                .lineLimit(2)
                .multilineTextAlignment(.leading)
                .padding(.horizontal, 4)
        }
        .padding(10)
        .background(
            RoundedRectangle(cornerRadius: 26, style: .continuous)
                .fill(.background)
        )
        .shadow(color: .black.opacity(0.08), radius: 9, y: 4)
    }
}

private struct ThumbnailView: View {
    let url: URL?

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [Color.blue.opacity(0.20), Color.yellow.opacity(0.28)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )

            if let url {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .scaledToFill()
                    case .failure:
                        placeholder
                    default:
                        ProgressView()
                            .controlSize(.large)
                    }
                }
            } else {
                placeholder
            }
        }
        .clipped()
    }

    private var placeholder: some View {
        VStack(spacing: 6) {
            Text("▶️")
                .font(.system(size: 42))
            Text("Video")
                .font(.headline)
        }
    }
}
