import Foundation
import SwiftUI

enum VideoCategory: String, CaseIterable, Codable, Identifiable {
    case buses = "Buses"
    case tractors = "Tractors"
    case jcbs = "JCBs"
    case trucks = "Trucks"
    case cars = "Cars"
    case farms = "Farms"
    case villages = "Villages"
    case construction = "Construction"
    case allVideos = "All Videos"

    var id: String { rawValue }

    var emoji: String {
        switch self {
        case .buses: return "🚌"
        case .tractors: return "🚜"
        case .jcbs: return "🚧"
        case .trucks: return "🚛"
        case .cars: return "🚗"
        case .farms: return "🌾"
        case .villages: return "🏘️"
        case .construction: return "🏗️"
        case .allVideos: return "⭐"
        }
    }

    var subtitle: String {
        switch self {
        case .buses: return "Big buses"
        case .tractors: return "Tractor fun"
        case .jcbs: return "Diggers & JCBs"
        case .trucks: return "Big trucks"
        case .cars: return "Cars & rides"
        case .farms: return "Farm adventures"
        case .villages: return "Village life"
        case .construction: return "Building time"
        case .allVideos: return "Everything"
        }
    }
}

struct VideoItem: Codable, Identifiable, Hashable {
    let id: String
    let title: String
    let thumbnailURL: URL?
    let videoURL: URL?
    let publishedAt: Date?
    let description: String?
    let categories: [VideoCategory]

    init(
        id: String,
        title: String,
        thumbnailURL: URL? = nil,
        videoURL: URL? = nil,
        publishedAt: Date? = nil,
        description: String? = nil,
        categories: [VideoCategory] = []
    ) {
        self.id = id
        self.title = title
        self.thumbnailURL = thumbnailURL
        self.videoURL = videoURL
        self.publishedAt = publishedAt
        self.description = description
        self.categories = categories
    }

    var resolvedCategories: [VideoCategory] {
        categories.isEmpty
            ? CategoryClassifier.categories(for: title + " " + (description ?? ""))
            : categories
    }

    var youtubeURL: URL? {
        if let videoURL { return videoURL }
        guard !id.isEmpty else { return nil }
        return URL(string: "https://www.youtube.com/watch?v=\(id)")
    }
}
