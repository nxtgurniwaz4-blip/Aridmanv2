import Foundation 
import SwiftUI

@MainActor 
final class VideoCatalog: ObservableObject { 
@Published private(set) var videos: [VideoItem] = [] 
@Published private(set) var isLoading = false 
@Published private(set) var errorMessage: String?

private let cache = AppCache.shared

private let cacheDuration: TimeInterval = 6 * 60 * 60
private let maxResults = 25

/*
 IMPORTANT:
 Replace this with your YouTube Data API v3 key.

 Do NOT commit a real key to a public GitHub repository.
 For a quick private build, you can put the key here.
*/
private let youtubeAPIKey = ""

private let categoryQueries: [VideoCategory: String] = [
    .buses: "buses",
    .tractors: "tractors",
    .jcbs: "JCB excavator",
    .trucks: "trucks",
    .cars: "cars",
    .farms: "farming farm",
    .villages: "Indian village life",
    .construction: "construction machines"
]

init() {
    loadCachedCatalog()

    Task {
        await refreshIfNeeded()
    }
}

var isEmpty: Bool {
    videos.isEmpty
}

func videos(for category: VideoCategory) -> [VideoItem] {
    guard category != .allVideos else {
        return videos
    }

    return videos.filter {
        $0.resolvedCategories.contains(category)
    }
}

func replace(with newVideos: [VideoItem]) {
    videos = newVideos
    saveCatalog()
}

func refresh() async {
    await refreshAllCategories(force: true)
}

// MARK: - Initial loading

private func loadCachedCatalog() {
    Task {
        guard let data = await cache.read(named: "catalog.json") else {
            return
        }

        guard let decoded = try? JSONDecoder.aridman.decode(
            [VideoItem].self,
            from: data
        ) else {
            return
        }

        self.videos = decoded
    }
}

private func refreshIfNeeded() async {
    guard !isLoading else {
        return
    }

    let timestamp = await readCacheTimestamp()

    if let timestamp {
        let age = Date().timeIntervalSince(timestamp)

        if age < cacheDuration && !videos.isEmpty {
            return
        }
    }

    await refreshAllCategories(force: false)
}

// MARK: - YouTube

private func refreshAllCategories(force: Bool) async {
    guard !youtubeAPIKey.isEmpty,
          youtubeAPIKey != "AIzaSyBm0OzNHk3aOZIse1R3GNlPfOe6mHjWDF4" else {
        errorMessage = "YouTube API key is not configured."
        return
    }

    if isLoading {
        return
    }

    isLoading = true
    errorMessage = nil

    defer {
        isLoading = false
    }

    var collected: [VideoItem] = []
    var seenIDs = Set<String>()

    for category in VideoCategory.allCases {
        guard category != .allVideos else {
            continue
        }

        do {
            let categoryVideos = try await searchYouTube(
                query: categoryQueries[category] ?? category.rawValue
            )

            for video in categoryVideos {
                guard !seenIDs.contains(video.id) else {
                    continue
                }

                seenIDs.insert(video.id)
                collected.append(video)
            }
        } catch {
            print("YouTube search failed for \(category.rawValue): \(error)")
        }
    }

    if !collected.isEmpty {
        videos = collected
        saveCatalog()
        await writeCacheTimestamp()
    } else if videos.isEmpty {
        errorMessage = "No videos could be loaded."
    }
}

private func searchYouTube(query: String) async throws -> [VideoItem] {
    var components = URLComponents(
        string: "https://www.googleapis.com/youtube/v3/search"
    )

    components?.queryItems = [
        URLQueryItem(name: "part", value: "snippet"),
        URLQueryItem(name: "q", value: query),
        URLQueryItem(name: "type", value: "video"),
        URLQueryItem(
            name: "maxResults",
            value: String(maxResults)
        ),
        URLQueryItem(name: "order", value: "relevance"),
        URLQueryItem(name: "regionCode", value: "IN"),
        URLQueryItem(name: "relevanceLanguage", value: "en"),
        URLQueryItem(name: "safeSearch", value: "strict"),
        URLQueryItem(name: "key", value: youtubeAPIKey)
    ]

    guard let url = components?.url else {
        throw YouTubeError.invalidURL
    }

    var request = URLRequest(url: url)
    request.httpMethod = "GET"
    request.timeoutInterval = 20

    let (data, response) = try await URLSession.shared.data(for: request)

    guard let httpResponse = response as? HTTPURLResponse else {
        throw YouTubeError.invalidResponse
    }

    guard (200...299).contains(httpResponse.statusCode) else {
        if let apiError = try? JSONDecoder().decode(
            YouTubeAPIErrorResponse.self,
            from: data
        ) {
            let message = apiError.error?.message ?? "YouTube API error"
            throw YouTubeError.api(message)
        }

        throw YouTubeError.httpStatus(httpResponse.statusCode)
    }

    let decoded = try JSONDecoder().decode(
        YouTubeSearchResponse.self,
        from: data
    )

    return decoded.items.compactMap { item in
        guard let videoID = item.id.videoID,
              !videoID.isEmpty else {
            return nil
        }

        let title = item.snippet.title
        let description = item.snippet.description

        let categories = CategoryClassifier.categories(
            for: "\(title) \(description)"
        )

        let thumbnailURL =
            item.snippet.thumbnails?.high?.url
            ?? item.snippet.thumbnails?.medium?.url
            ?? item.snippet.thumbnails?.defaultThumbnail?.url

        let videoURL = URL(
            string: "https://www.youtube.com/watch?v=\(videoID)"
        )

        return VideoItem(
            id: videoID,
            title: title,
            thumbnailURL: thumbnailURL,
            videoURL: videoURL,
            publishedAt: parseDate(item.snippet.publishedAt),
            description: description,
            categories: categories
        )
    }
}

// MARK: - Cache

private func saveCatalog() {
    guard let data = try? JSONEncoder.aridman.encode(videos) else {
        return
    }

    Task {
        try? await cache.write(
            data,
            named: "catalog.json"
        )
    }
}

private func readCacheTimestamp() async -> Date? {
    guard let data = await cache.read(
        named: "catalog_timestamp.json"
    ) else {
        return nil
    }

    return try? JSONDecoder().decode(
        Date.self,
        from: data
    )
}

private func writeCacheTimestamp() async {
    guard let data = try? JSONEncoder().encode(Date()) else {
        return
    }

    try? await cache.write(
        data,
        named: "catalog_timestamp.json"
    )
}

// MARK: - Date

private func parseDate(_ value: String?) -> Date? {
    guard let value else {
        return nil
    }

    return ISO8601DateFormatter().date(from: value)
}
}

// MARK: - YouTube API models

private struct YouTubeSearchResponse: Decodable { 
let items: [YouTubeSearchItem] 
}

private struct YouTubeSearchItem: Decodable { 
let id: YouTubeVideoID 
let snippet: YouTubeSnippet 
}

private struct YouTubeVideoID: Decodable { 
let kind: String? 
let videoID: String?

enum CodingKeys: String, CodingKey {
    case kind
    case videoID = "videoId"
}
}

private struct YouTubeSnippet: Decodable { 
let title: String 
let description: String 
let publishedAt: String? 
let thumbnails: YouTubeThumbnails? 
}

private struct YouTubeThumbnails: Decodable { 
let defaultThumbnail: YouTubeThumbnail? 
let medium: YouTubeThumbnail? 
let high: YouTubeThumbnail?

enum CodingKeys: String, CodingKey {
    case defaultThumbnail = "default"
    case medium
    case high
}
}

private struct YouTubeThumbnail: Decodable { 
let url: URL 
let width: Int? 
let height: Int? 
}

private struct YouTubeAPIErrorResponse: Decodable { 
let error: YouTubeAPIError? 
}

private struct YouTubeAPIError: Decodable { 
let message: String? 
let code: Int? 
}

// MARK: - Errors

private enum YouTubeError: LocalizedError { 
case invalidURL 
case invalidResponse 
case httpStatus(Int) 
case api(String)

var errorDescription: String? {
    switch self {
    case .invalidURL:
        return "Invalid YouTube API URL."

    case .invalidResponse:
        return "Invalid response from YouTube."

    case .httpStatus(let status):
        return "YouTube returned HTTP \(status)."

    case .api(let message):
        return message
    }
}
}

// MARK: - JSON helpers

extension JSONEncoder { 
static var aridman: JSONEncoder { 
let encoder = JSONEncoder() 
encoder.dateEncodingStrategy = .iso8601 
return encoder 
} 
}

extension JSONDecoder { 
static var aridman: JSONDecoder { 
let decoder = JSONDecoder() 
decoder.dateDecodingStrategy = .iso8601 
return decoder 
} 
}*JY/B5|x[*4J6OJ@C*J
