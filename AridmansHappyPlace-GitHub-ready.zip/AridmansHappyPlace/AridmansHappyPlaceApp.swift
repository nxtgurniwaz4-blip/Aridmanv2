import SwiftUI

@main
struct AridmansHappyPlaceApp: App {
    @StateObject private var catalog = VideoCatalog()

    var body: some Scene {
        WindowGroup {
            HomeView()
                .environmentObject(catalog)
                .preferredColorScheme(nil)
        }
    }
}
