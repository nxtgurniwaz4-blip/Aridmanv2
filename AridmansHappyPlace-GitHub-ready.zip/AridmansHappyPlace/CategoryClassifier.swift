import Foundation

enum CategoryClassifier {
    static func categories(for text: String) -> [VideoCategory] {
        let value = text.folding(
            options: [.diacriticInsensitive, .caseInsensitive],
            locale: .current
        )

        var result: [VideoCategory] = []

        add(.buses, keywords: ["bus", "school bus", "volvo bus", "roadways"], to: value, result: &result)
        add(.tractors, keywords: ["tractor", "farm tractor", "mahindra", "sonalika", "swaraj", "john deere"], to: value, result: &result)
        add(.jcbs, keywords: ["jcb", "excavator", "backhoe", "digger", "loader"], to: value, result: &result)
        add(.trucks, keywords: ["truck", "lorry", "tipper", "dum​​per", "container truck"], to: value, result: &result)
        add(.cars, keywords: ["car", "cars", "suv", "jeep", "automobile"], to: value, result: &result)
        add(.farms, keywords: ["farm", "farming", "khet", "field", "crop", "harvest", "wheat", "धान", "गांव की खेती"], to: value, result: &result)
        add(.villages, keywords: ["village", "gaon", "गांव", "rural", "village life"], to: value, result: &result)
        add(.construction, keywords: ["construction", "building", "road work", "road construction", "machine work", "digging"], to: value, result: &result)

        return result.isEmpty ? [.allVideos] : result
    }

    private static func add(
        _ category: VideoCategory,
        keywords: [String],
        to text: String,
        result: inout [VideoCategory]
    ) {
        if keywords.contains(where: text.contains), !result.contains(category) {
            result.append(category)
        }
    }
}
