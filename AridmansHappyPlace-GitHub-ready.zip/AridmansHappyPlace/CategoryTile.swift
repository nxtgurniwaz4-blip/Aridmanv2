import SwiftUI

struct CategoryTile: View {
    let category: VideoCategory

    var body: some View {
        VStack(spacing: 10) {
            Text(category.emoji)
                .font(.system(size: 56))

            Text(category.rawValue)
                .font(.system(size: 21, weight: .heavy, design: .rounded))
                .foregroundStyle(.primary)
                .minimumScaleFactor(0.75)
                .lineLimit(1)

            Text(category.subtitle)
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.secondary)
                .lineLimit(1)
        }
        .frame(maxWidth: .infinity, minHeight: 155)
        .padding(12)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(.background)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .strokeBorder(.primary.opacity(0.08), lineWidth: 2)
        )
        .shadow(color: .black.opacity(0.08), radius: 10, y: 5)
        .contentShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .accessibilityLabel("\(category.rawValue). \(category.subtitle)")
    }
}
