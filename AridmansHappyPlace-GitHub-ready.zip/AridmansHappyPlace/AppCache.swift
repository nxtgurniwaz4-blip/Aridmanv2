import Foundation

actor AppCache {
    static let shared = AppCache()

    // Target is approximately 2 GB. URLCache itself is managed by the OS,
    // while this directory is used for catalog/thumbnail cache data.
    private let maxBytes: Int64 = 2 * 1024 * 1024 * 1024
    private let folderName = "AridmansHappyPlaceCache"

    private var cacheDirectory: URL {
        let base = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent(folderName, isDirectory: true)
    }

    private init() {
        let directory = cacheDirectory
        try? FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )
    }

    func write(_ data: Data, named name: String) throws {
        let safeName = name.replacingOccurrences(of: "/", with: "_")
        let destination = cacheDirectory.appendingPathComponent(safeName)
        try data.write(to: destination, options: .atomic)
        try trimIfNeeded()
    }

    func read(named name: String) -> Data? {
        let safeName = name.replacingOccurrences(of: "/", with: "_")
        let url = cacheDirectory.appendingPathComponent(safeName)
        return try? Data(contentsOf: url)
    }

    func clear() throws {
        try FileManager.default.removeItem(at: cacheDirectory)
        try FileManager.default.createDirectory(
            at: cacheDirectory,
            withIntermediateDirectories: true
        )
    }

    private func trimIfNeeded() throws {
        let files = try FileManager.default.contentsOfDirectory(
            at: cacheDirectory,
            includingPropertiesForKeys: [.fileSizeKey, .contentModificationDateKey],
            options: [.skipsHiddenFiles]
        )

        var entries: [(url: URL, size: Int64, date: Date)] = []
        var total: Int64 = 0

        for url in files {
            let values = try url.resourceValues(
                forKeys: [.fileSizeKey, .contentModificationDateKey]
            )
            let size = Int64(values.fileSize ?? 0)
            let date = values.contentModificationDate ?? .distantPast
            entries.append((url, size, date))
            total += size
        }

        guard total > maxBytes else { return }

        for entry in entries.sorted(by: { $0.date < $1.date }) {
            try? FileManager.default.removeItem(at: entry.url)
            total -= entry.size
            if total <= maxBytes { break }
        }
    }
}
