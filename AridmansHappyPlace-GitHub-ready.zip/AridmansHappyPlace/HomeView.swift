import SwiftUI

struct HomeView: View {
    @EnvironmentObject private var catalog: VideoCatalog

    private let columns = [
        GridItem(.adaptive(minimum: 150), spacing: 18)
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                LinearGradient(
                    colors: [
                        Color.yellow.opacity(0.22),
                        Color.cyan.opacity(0.16),
                        Color.white
                    ],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .ignoresSafeArea()

                ScrollView {
                    VStack(spacing: 22) {
                        header

                        LazyVGrid(columns: columns, spacing: 18) {
                            ForEach(VideoCategory.allCases) { category in
                                NavigationLink {
                                    VideoListView(category: category)
                                } label: {
                                    CategoryTile(category: category)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 18)

                        if catalog.isEmpty {
                            Text("Videos will appear here when a catalog is loaded.")
                                .font(.footnote.weight(.medium))
                                .foregroundStyle(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 30)
                                .padding(.bottom, 20)
                        }
                    }
                    .padding(.top, 16)
                }
            }
            .navigationBarHidden(true)
        }
    }

    private var header: some View {
        VStack(spacing: 6) {
            Text("Aridman’s Happy Place")
                .font(.system(size: 32, weight: .heavy, design: .rounded))
                .multilineTextAlignment(.center)

            Text("Pick something fun! 😊")
                .font(.system(size: 19, weight: .semibold, design: .rounded))
                .foregroundStyle(.secondary)
        }
        .padding(.horizontal, 20)
    }
}
