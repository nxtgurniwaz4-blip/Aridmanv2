import Foundation
import SwiftUI

@MainActor
final class VideoCatalog: ObservableObject {
    @Published private(set) var videos: [VideoItem] = []

    private let cache = AppCache.shared
    private let catalogFile = "catalog.json"

    init() {
        loadCachedCatalog()
    }

    var isEmpty: Bool {
        videos.isEmpty
    }

    func videos(for category: VideoCategory) -> [VideoItem] {
        guard category != .allVideos else { return videos }
        return videos.filter { $0.resolvedCategories.contains(category) }
    }

    func replace(with newVideos: [VideoItem]) {
        videos = newVideos
        saveCatalog()
    }

    private func loadCachedCatalog() {
        Task {
            if let data = await cache.read(named: catalogFile),
               let decoded = try? JSONDecoder.aridman.decode([VideoItem].self, from: data) {
                self.videos = decoded
            }
        }
    }

    private func saveCatalog() {
        guard let data = try? JSONEncoder.aridman.encode(videos) else { return }
        Task {
            try? await cache.write(data, named: catalogFile)
        }
    }
}

extension JSONEncoder {
    static var aridman: JSONEncoder {
        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        return encoder
    }
}

extension JSONDecoder {
    static var aridman: JSONDecoder {
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601
        return decoder
    }
}
